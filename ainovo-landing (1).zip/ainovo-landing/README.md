# Ainovo – AI-lösningar för småföretag

Den här sidan är en enkel landningssida för att sälja in AI-tjänster till små och medelstora företag. Skapad med Next.js och Tailwind CSS.

## Funktioner
- Tydlig presentation av tjänster
- Enkel call-to-action (mailkontakt)
- Responsiv design

## Så här kör du sidan lokalt

1. Klona repot
2. Kör `npm install`
3. Kör `npm run dev`
export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-900 p-8 flex flex-col items-center justify-center space-y-8">
      <h1 className="text-4xl font-bold text-center max-w-2xl leading-tight">
        Smarta AI-lösningar för företag som vill spara tid och jobba smartare
      </h1>
      <p className="text-lg text-center max-w-xl">
        Vi hjälper små och medelstora företag att implementera enkla och effektiva AI-verktyg för att automatisera arbetsflöden, skapa innehåll och förbättra kundupplevelsen – utan tekniskt krångel.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
        <div className="bg-gray-100 rounded-2xl shadow-md p-6">
          <h2 className="text-xl font-semibold mb-2">AI-Setup</h2>
          <p>Vi sätter upp rätt AI-verktyg för din verksamhet – från ChatGPT till automatiseringar och AI-chattbottar.</p>
        </div>
        <div className="bg-gray-100 rounded-2xl shadow-md p-6">
          <h2 className="text-xl font-semibold mb-2">Automatisering</h2>
          <p>Vi automatiserar dina uppgifter med smarta flöden i Zapier eller Make. Spar tid, minska misstag.</p>
        </div>
        <div className="bg-gray-100 rounded-2xl shadow-md p-6">
          <h2 className="text-xl font-semibold mb-2">Utbildning & Support</h2>
          <p>Vi visar hur du använder AI i praktiken och erbjuder löpande stöd för dig och ditt team.</p>
        </div>
      </div>

      <div className="text-center mt-8">
        <h3 className="text-2xl font-semibold mb-4">Redo att spara tid och jobba smartare?</h3>
        <p className="mb-4">Boka en kostnadsfri 30-minuters demo där vi visar vad AI kan göra för just ditt företag.</p>
        <a
          href="mailto:kontakt@ainovo.ai"
          className="inline-block px-6 py-3 bg-black text-white rounded-2xl shadow-lg hover:bg-gray-800 transition"
        >
          Kontakta oss
        </a>
      </div>
    </div>
  );
}